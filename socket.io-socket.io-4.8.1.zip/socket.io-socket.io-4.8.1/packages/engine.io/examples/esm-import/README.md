## How to use

```
$ npm link ../..
$ node index.js
```
