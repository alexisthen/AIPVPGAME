
# eio-latency

## Running

First, execute:

```
$ npm install
```

Then execute the server:

```
$ node index
```

And point your browser to `localhost:3000` (if PORT is set in your environment, then it will use that instead).
