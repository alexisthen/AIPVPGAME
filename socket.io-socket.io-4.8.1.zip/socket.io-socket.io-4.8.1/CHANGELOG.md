# Changelog

Here are the detailed changelogs for each package in this monorepo:

| Package                        | Changelog                                               |
|--------------------------------|---------------------------------------------------------|
| `engine.io`                    | [link](packages/engine.io/CHANGELOG.md)                 |
| `engine.io-client`             | [link](packages/engine.io-client/CHANGELOG.md)          |
| `engine.io-parser`             | [link](packages/engine.io-parser/CHANGELOG.md)          |
| `socket.io`                    | [link](packages/socket.io/CHANGELOG.md)                 |
| `socket.io-adapter`            | [link](packages/socket.io-adapter/CHANGELOG.md)         |
| `socket.io-client`             | [link](packages/socket.io-client/CHANGELOG.md)          |
| `@socket.io/cluster-engine`    | [link](packages/socket.io-cluster-engine/CHANGELOG.md)  |
| `@socket.io/component-emitter` | [link](packages/socket.io-component-emitter/History.md) |
| `socket.io-parser`             | [link](packages/socket.io-parser/CHANGELOG.md)          |
