
# Socket.IO WebTransport example

## How to use

```shell
# generate a self-signed certificate
$ ./generate_cert.sh

# install dependencies
$ npm i

# start the server
$ node index.js

# open a Chrome browser
$ ./open_chrome.sh
```
