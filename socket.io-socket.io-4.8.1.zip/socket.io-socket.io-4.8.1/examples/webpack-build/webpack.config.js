export default {
  entry: "./index.js",
  mode: "production",
  output: {
    filename: "bundle.js",
  },
};
